import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InventoryOrganizationComponent } from './inventory-organization.component';

describe('InventoryOrganizationComponent', () => {
  let component: InventoryOrganizationComponent;
  let fixture: ComponentFixture<InventoryOrganizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InventoryOrganizationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InventoryOrganizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
